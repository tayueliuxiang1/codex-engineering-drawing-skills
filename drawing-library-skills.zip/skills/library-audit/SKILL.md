---
name: library-audit
description: Audit a drawing library whose catalogue is an Excel workbook and whose files sit in a sibling folder, then repair it so every catalogue row has its file and every delivered drawing has a row. Use for "is this batch already in the library", adding missing records, and keeping catalogue and folder in one-to-one correspondence.
---

# Audit and repair a drawing library

A library is two halves that drift: a workbook of records and a folder of drawings. The invariant to hold is **every catalogue row has at least one file, and every single-drawing file has a row**. Audit first, repair second, verify the invariant third.

Read [references/xls-and-com.md](references/xls-and-com.md) before touching the workbook and [references/matching-and-repair.md](references/matching-and-repair.md) before deciding a match or appending a row.

## 1. Load both halves

- Catalogue: `scripts/dump_xls.ps1` exports the sheet to TSV through Excel COM. Plain spreadsheet libraries cannot read a legacy `.xls`; do not try to convert it to edit it.
- Files: list the drawing folder, group by stem, and strip non-identifying suffixes (`会签`, `（副本）`, `-签字版`) before comparing.
- Record both counts. A mismatch between record count and file group count is the first thing to explain, not to fix.

## 2. Match each delivered drawing

Order of evidence, stopping at the first hit:

1. **Exact identifier** — the mould number as printed.
2. **Same number after dropping a prefix** (`XL-`, `JA-`) — report the difference, do not silently treat it as equal.
3. **Measured dimensions** — only for sheets with no printed number, and only within the same project, tolerance 0.5 mm. If several records tie, list them all instead of picking one.

Never match on fuzzy text, and never widen the dimension tolerance to force a hit.

## 3. Classify what is missing

| Finding | Action |
| --- | --- |
| Delivered drawing has a library row | Nothing to add. Report the row number. |
| Delivered drawing has no row | **Repair**: append a row and copy the file into the drawing folder. |
| Catalogue row has no file | **Violation**: report it. Never invent a file; ask whether the record is obsolete. |
| Folder file has no row, and it is a single drawing | Candidate for repair, but confirm it is a drawing and not a bundle, an index, or a backup. |
| Folder file is a combined bundle (a whole set stitched as `…会签.pdf`), a catalogue/index PDF, or a `.bak` | Report as an orphan. Do **not** add a row. |

## 4. Repair

Back up the workbook before the first write — it is a production file and Excel COM writes it in place.

For each drawing that needs a record:

1. Append the row after the last data row, copying the cell styles of the row above.
2. Fill what the drawing actually states: 序号, 项目号 (ASCII only), 模具编号, 材质, 截面图, 总宽, 总高, 型材类别, 图纸类别. Leave unknown fields blank and name them in the report — a blank is honest, a guess is not.
3. Copy the drawing into the library folder as `<模具编号>.dwg`. Copy, never move: the split output stays where it is.
4. If a signed-and-sealed PDF exists for the same drawing, copy it as `<模具编号>会签.pdf` and set 图纸类别 accordingly (`cad+会签`).

Write the row and the file in the same operation, so a failure cannot leave a row pointing at nothing.

## 5. Verify the invariant

Re-open the workbook, re-list the folder, and assert:

- every catalogue row resolves to at least one `.dwg` or `.pdf`;
- every newly added row's file exists with the exact expected name;
- the record count grew by exactly the number of repairs;
- the drawing folder gained exactly those files and nothing else;
- every remaining orphan is enumerated as a bundle, an index, or a backup.

Then reconcile the counts in the report: added rows, added files, remaining violations, orphans. A repair that leaves the invariant false must be reported as failed, not as done.

## 6. Defaults

- Never edit the catalogue in place without a timestamped backup.
- Never delete a file or a row during a repair, even when it looks like a duplicate; report it and let a human decide.
- Keep 项目号 ASCII, even when 模具编号 contains Chinese.
- One row per drawing; several formats of the same drawing share one row.
