# Dump the first worksheet of an .xls/.xlsx catalogue to TSV, read-only.
# Paths arrive through environment variables because Windows PowerShell 5.1
# reads this file as ANSI and would mangle a non-ASCII path passed as text.
$ErrorActionPreference = 'Stop'
$xls = $env:REF_XLS
$out = $env:REF_OUT
if (-not $xls -or -not $out) { throw 'set REF_XLS and REF_OUT' }

$lines = New-Object System.Collections.Generic.List[string]
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false
try {
    $wb = $excel.Workbooks.Open($xls, $false, $true)
    $ws = $wb.Worksheets.Item(1)
    $ur = $ws.UsedRange
    $rows = $ur.Rows.Count
    $cols = [Math]::Min(15, $ur.Columns.Count)
    $head = @('ROW')
    foreach ($c in 1..$cols) { $head += ('C' + $c) }
    $lines.Add(($head -join "`t"))
    foreach ($r in 1..$rows) {
        $vals = @()
        foreach ($c in 1..$cols) {
            $t = $ws.Cells.Item($r, $c).Text
            $t = $t -replace "`r", " " -replace "`n", " " -replace "`t", " "
            $vals += $t
        }
        $lines.Add(('R' + $r) + "`t" + ($vals -join "`t"))
    }
    $wb.Close($false)
} finally {
    $excel.Quit()
    [void][System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)
}
[System.IO.File]::WriteAllLines($out, $lines, (New-Object System.Text.UTF8Encoding($false)))
