"""Reconcile a catalogue TSV against a drawing folder, in both directions.

Usage:
    python reconcile.py --tsv catalogue.tsv --folder "X:\\型材图库" [--out report.csv]

Prints counts and the two gap lists; writes a CSV when --out is given.
Exit code is 0 even when gaps exist: a gap is a finding, not a crash.
"""
import argparse
import csv
import os
import re
import unicodedata
from collections import defaultdict

SUFFIX = re.compile(r'(会签|（副本）|\(副本\)|-签字版|签字版|_签字版)$')
CODES = ['序号', '项目号', '模具编号', '材质', '截面图', '总宽', '总高', '定尺',
         '物料编码', '图纸类别', '可用', '存放地', '兼容', '型材类型', '备注']


def norm(s):
    s = unicodedata.normalize('NFKC', str(s or ''))
    s = s.replace('–', '-').replace('—', '-').replace('－', '-').replace('_', '-')
    return re.sub(r'\s+', '', s).upper()


def base_key(stem):
    s = stem
    for _ in range(3):
        new = SUFFIX.sub('', s)
        if new == s:
            break
        s = new
    return norm(s)


def load_rows(tsv):
    rows = []
    for line in open(tsv, encoding='utf-8'):
        p = line.rstrip('\n').split('\t')
        if len(p) < 4 or not p[0].startswith('R') or not p[0][1:].isdigit():
            continue
        idx = int(p[0][1:])
        if idx < 3:                      # title and header rows
            continue
        rec = dict(zip(CODES, p[1:]))
        if rec.get('模具编号', '').strip():
            rows.append({'row': idx, 'project': rec['项目号'].strip(),
                         'code': rec['模具编号'].strip(), 'cat': rec['图纸类别'].strip()})
    return rows


def load_files(folder):
    groups = defaultdict(lambda: {'dwg': [], 'pdf': [], 'other': []})
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        stem, ext = os.path.splitext(name)
        ext = ext.lower()
        key = base_key(stem)
        if ext == '.dwg':
            groups[key]['dwg'].append(name)
        elif ext == '.pdf':
            groups[key]['pdf'].append(name)
        else:
            groups[key]['other'].append(name)
    return groups


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tsv', required=True)
    ap.add_argument('--folder', required=True)
    ap.add_argument('--out')
    a = ap.parse_args()

    rows = load_rows(a.tsv)
    files = load_files(a.folder)
    codes = {norm(r['code']) for r in rows}

    no_file = [r for r in rows if not (files.get(norm(r['code']), {}).get('dwg')
                                       or files.get(norm(r['code']), {}).get('pdf'))]
    orphans = {k: v for k, v in files.items() if k not in codes}

    print(f'catalogue rows : {len(rows)}')
    print(f'distinct files : {len(files)}')
    print(f'rows without file : {len(no_file)}')
    print(f'files without row : {len(orphans)}')

    if no_file:
        print('\n-- catalogue row, no file --')
        for r in no_file:
            print(f"  row {r['row']:>4}  {r['code']:<24} {r['project']:<12} {r['cat']}")
    if orphans:
        print('\n-- file, no catalogue row --')
        for key, hit in sorted(orphans.items()):
            names = hit['dwg'] + hit['pdf'] + hit['other']
            print(f"  {key:<24} {', '.join(names[:3])}{' ...' if len(names) > 3 else ''}")

    if a.out:
        with open(a.out, 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(['类型', 'Excel行号', '模具编号', '项目号', '图纸类别', '图库文件'])
            for r in no_file:
                w.writerow(['表格有图库无', r['row'], r['code'], r['project'], r['cat'], ''])
            for key, hit in sorted(orphans.items()):
                names = hit['dwg'] + hit['pdf'] + hit['other']
                w.writerow(['图库有表格无', '', key, '', '', ' / '.join(names)])
        print('\nreport ->', a.out)


if __name__ == '__main__':
    main()
