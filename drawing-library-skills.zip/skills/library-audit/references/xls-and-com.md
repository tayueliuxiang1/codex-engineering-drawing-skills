# Reading and writing a legacy `.xls` catalogue

`openpyxl` cannot open `.xls` at all, and converting the file first is not an option when the catalogue must stay in its original format. Use the installed Excel through COM.

## Dump rows to TSV (read-only)

`scripts/dump_xls.ps1` opens the workbook read-only and writes one tab-separated line per row, using the cell's displayed text:

```powershell
$env:REF_XLS = 'C:\path\catalogue.xls'
$env:REF_OUT = 'C:\work\catalogue.tsv'
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\dump_xls.ps1
```

Two traps cost real time here:

- **Windows PowerShell 5.1 reads `.ps1` files as ANSI.** A UTF-8 script containing Chinese paths turns into mojibake and Excel reports "file not found". Pass paths through environment variables and keep the script body ASCII; do not inline non-ASCII literals.
- **Never pass Unicode paths as command-line arguments** to `powershell -File`; the same encoding mismatch applies. Environment variables survive intact.

`|` or `,` inside cell text will break naive CSV parsing; tab separators plus stripping `\r\n\t` from cell text keep one row per line.

## Write rows back

Appending a row through COM has four traps, each of which fails *silently* — the script reports success while the sheet is wrong. The order below is the one that survived an end-to-end rehearsal.

```powershell
$ws = $wb.Worksheets.Item(1)

# 1) the last row that actually carries an identifier — UsedRange usually ends with
#    several formatted-but-empty rows, and appending after those leaves a gap
$lastData = 2
for ($r = 3; $r -le $lastRowInUsedRange; $r++) {
    if (("" + $ws.Cells.Item($r, 3).Text).Trim() -ne '') { $lastData = $r }
}
$newRow = $lastData + 1

# 2) inherit formatting by copying that row — this copies its VALUES too
$ws.Rows.Item($lastData).Copy($ws.Rows.Item($newRow)) | Out-Null

# 3) overwrite the copied values with this row's own values
$arr = New-Object 'object[,]' 1, 15
for ($i = 0; $i -lt 15; $i++) { $arr[0, $i] = $values[$i] }
$ws.Range(("A{0}:O{0}" -f $newRow)).Value2 = $arr

$wb.Save()
```

Why this order and not the obvious one:

| Trap | What happens |
| --- | --- |
| `Copy()` with no destination, then assigning `Value2` | `InvalidCastException` — Excel is in clipboard mode |
| `Copy(destination)` after writing the values | Silently **overwrites them with the previous row's data**, because `Range.Copy(dest)` carries contents, not just formatting |
| `Copy()` + `PasteSpecial(-4122)` (formats only) as the last step | Works, but needs clipboard mode; keep it for cases where values must not be touched |
| `$excel.CutCopyMode = 0` | Throws: the property is a typed enum accepting only `xlCopy`/`xlCut`; clear the mode by other means or avoid entering it |
| Appending after `UsedRange` | Lands after trailing empty rows, leaving a hole in the table |

`Save()` on an `.xls` keeps the format; `SaveAs` with the wrong filter silently upgrades the file to `.xlsx`.

Back up before the first write: `Copy-Item $xls "$xls.bak-<timestamp>"`. If the workbook is open in Excel, `Open` returns the already-open instance and `Save` fails with a sharing violation — detect that up front.

A failed attempt still rewrites the file's container: after one aborted run the production `.xls` had different bytes but identical data. **Compare dumped data, not file hashes**, when you need to prove the catalogue is unchanged; keep the hash comparison for proving a restore succeeded.

## Verify after writing

Re-dump to TSV and assert: the row count grew by exactly the number of additions, the appended row reads back with the intended values (not the previous row's), and the file it points at exists. Excel normalises text (trimmed spaces, fixed decimals), so compare normalised values, not raw strings.
