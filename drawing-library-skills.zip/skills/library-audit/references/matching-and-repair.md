# Matching and repair rules

## One identifier, several spellings

Normalise before comparing: NFKC, unify dash variants (`– — － _` → `-`), strip all whitespace, uppercase. Keep everything else.

| Situation | Verdict |
| --- | --- |
| Identical after normalisation | Exact match |
| Same after dropping one of the known prefixes (`XL-`, `JA-`, `AP-`, `HN-`) | Match, but report which side carries the prefix |
| Same project, dimensions within 0.5 mm, no printed number | Match by measurement, report the evidence |
| Several records tie on measurement | List them all; never pick one silently |
| Anything else | Not a match — report it, do not stretch the rule |

Dimension matching exists for the sheets that carry no printed drawing number. Restrict the candidate set to the same project first: the same profile is often reused across projects, so a dimension-only search over the whole catalogue will attribute a drawing to the wrong project.

## What counts as a library file

- A single drawing named `<identifier>.dwg`, optionally with `会签`, `（副本）`, or `-签字版` before or after the extension.
- The same drawing as PDF, ordinary or signed-and-sealed.
- Not a library file: `.bak`, a combined set stitched into one PDF (for example `DJ2540会签.pdf` covering 01–11), a catalogue or index PDF, and anything whose stem is not an identifier.

Strip the cosmetic suffixes to get the comparison key, but keep the original names when reporting.

## Repairing a missing record

A rewrite of the rule the library has to satisfy: **the catalogue may not contain a row without a file, and every delivered single drawing must have a row.**

Order of operations, chosen so a crash cannot leave a row pointing at nothing:

1. Back up the workbook.
2. Copy the drawing into the folder as `<identifier>.dwg` (copy, not move; the delivered file stays where it is).
3. Append the row, fill what the drawing states, copy the previous row's formatting.
4. Save the workbook.
5. Re-run the audit.

If step 3 fails, delete the file copied in step 2 so the folder does not gain an orphan. If step 4 fails, the row is lost and the file becomes the orphan — the audit will show it, which is the point of running the audit after every repair.

Fields: 项目号 ASCII only; 模具编号 may contain Chinese; 总宽/总高 one decimal; 图纸类别 follows the files actually present (`cad`, `cad+pdf`, `cad+会签`, `会签版`, …); leave unreadable fields blank and name them in the report.

## Reporting

State four numbers: records before, files added, records added, violations remaining — plus the orphans with their classification. "Zero missing" is a legitimate result and should be reported as such, with the two counts that prove it.
