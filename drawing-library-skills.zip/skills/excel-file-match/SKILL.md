---
name: excel-file-match
description: Reconcile identifiers in an Excel workbook with a drawing library, copy matched files into a flat folder, mark matched cells yellow, and add missing records with section images and drawing metadata. Use for workbook-to-library reconciliation, not live Excel control.
---

# Reconcile a workbook against a drawing library

Both directions matter: a workbook row with no file, and a file with no workbook row, are two different findings and must not be collapsed into "unmatched".

## 1. Inputs

Confirm once, with defaults:

| Input | Default |
| --- | --- |
| Workbook, sheet, identifier column | column C |
| File search roots | the folder the user pointed at |
| Recursion | off unless the user means the whole tree |
| Included types | DWG and PDF |
| Destination | a flat folder, one level deep |
| Output workbook | a copy next to the source; source never edited |

If `drawing-split` already produced `拆分清单.csv`, use it as the authoritative identifier list (`图号`) and file list (`输出文件名`) instead of re-reading filenames. Do not re-derive identifiers from filenames when a manifest exists.

## 2. Build the match manifest first

Write a table before copying or editing anything. One row per workbook record and per discovered file:

`workbook · sheet · row · original cell value · candidate filename stem · equivalence rule applied · associated DWG/PDF · signature-and-seal review · file category · status`

Statuses, kept distinct: exact match, confirmed alias, missing file, ambiguous candidate, excluded by type or scope.

## 3. Match

- Read cell values as text. `0007` must not become `7`.
- Compare case-insensitively, trim outer whitespace, normalize full-width Latin/digits and dash variants, ignore spaces around separators. Never strip meaningful letters, prefixes, suffixes, or interior digits.
- Exact match first. Then only the alias rules the user or a project map confirmed — see [references/matching.md](references/matching.md).
- No fuzzy guessing on transposed digits, revision letters, or near-identical codes. Put candidates in a review list.
- Use project number plus mold number as the record key when both exist. Two projects sharing a mold number are not the same record.

## 4. Copy

- Copy confirmed matches into the destination root, flat, without per-source subfolders. Never move or delete a source.
- Never overwrite. Compare SHA-256 when a destination name collides: identical content keeps one copy, different content preserves the existing file and reports a conflict.
- A PDF visibly carrying both a signature and a seal: append `会签` to the destination copy's stem before the extension. Do not change the source, and do not append twice.
- Identify a signed-and-sealed PDF by inspecting content. One mark alone is an ordinary PDF.

## 5. Update the workbook copy

Load the `office-xlsx` skill and use its supported authoring route with the bundled Python and `openpyxl`. Open the source read-only, save to a new file. Details and the exact cell and image handling: [references/workbook-editing.md](references/workbook-editing.md).

- Yellow `#FFFF00` fill on the matched identifier cell only, never the whole row.
- Clear the old yellow marker on unmatched identifier cells only when the user wants yellow to mean "found".
- New records for files with no workbook row, using the workbook's existing headers: 项目号, 模具编号, 材质, 截面图, 总宽, 总高, 型材类型, 图纸类别.
- 项目号 is ASCII only — the mould number's leading ASCII run with its serial removed (`CN2337-12` → `CN2337`). 模具编号 and file names may legitimately contain Chinese; never strip them to tidy a column.
- Fill drawing-derived fields only on new rows. Do not backfill blanks in existing rows unless asked.
- Leave uncertain values blank and flag them. Never infer material from appearance.
- Dimensions come from printed overall annotations. If a sheet has none and the user explicitly authorises measuring, measure the drawn profile's bounding extent in drawing units, apply the title-block scale, record the method, and warn that draft angles and tolerances make it differ slightly from a dimensioned value. Never measure silently, and never derive a dimension from a viewport or a pixel estimate.

## 6. Verify

1. Reopen the saved workbook and read back the specific cells you changed — fills, values, and the inserted images.
2. Assert formulas and unrelated formatting survived.
3. Reconcile yellow cells against the manifest: only exact and confirmed-alias matches are yellow.
4. Assert the destination holds exactly the expected files, no unintended overwrite, and that the source workbook hash is unchanged.
5. Report matched existing rows, new records, workbook-only identifiers, alias corrections, collisions, skipped files, and both output paths.

## 7. Defaults worth stating in the report

Workbook copied, never edited in place. Files copied, never moved. Yellow on the identifier cell only. Files absent from the workbook become new rows and are also copied. Prefix and zero-padding aliases are project-specific: apply only what this task confirmed.
