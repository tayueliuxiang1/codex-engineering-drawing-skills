# Identifier matching rules

## Read values faithfully

- Treat every identifier as text, including numeric-looking `0007`. A numeric cast destroys leading zeros.
- Compare against filename stems after removing only the final extension.
- Case-insensitive; trim outer whitespace; normalize full-width Latin letters and digits; unify dash variants; ignore accidental spaces around separators.
- Do not strip meaningful letters, prefixes, suffixes, or interior digits.

## Allowed equivalences

Apply the narrowest rule the user or a project alias map confirmed. This skill ships no alias map on purpose.

| Difference | Default handling |
| --- | --- |
| Confirmed prefix alias, rest identical | Equivalent only when this task or an approved map confirms that prefix pair |
| Zero-padded serial difference, rest identical | Equivalent only when the confirmed map covers that numeric segment; keep the file's exact spelling when aligning the cell |
| Added or removed suffix | Equivalent only for an explicitly confirmed, row-specific alias; never generalize it |
| Anything else (other prefix/suffix change, transposed digits, changed character) | Do not auto-match; present the candidate and ask |

Two identifiers that merely look similar are different identifiers. `AB-123` versus `AB-132` is a transposition, not a typo to fix silently.

## Reconcile both directions

- Build the file inventory before deciding what is unmatched.
- A workbook row with no file is workbook-only. A file with no row is file-only and may need a **new record**, not a failed match.
- Key on project number plus mold number when both are available. Same mold number under two projects is two records.
- Group different formats of the same confirmed key under one record when the sheet layout uses one row per mold; copy each requested format once.
- Only mark a row found after the file is verified and either matched or added.

## Ambiguity and collisions

- Several files, different extensions, one identifier: copy all requested types, report one row matching several files.
- Several files of the same type for one identifier: list each candidate with its path and distinguishing metadata; do not pick by folder order.
- Two workbook rows sharing one identifier: mark every confirmed row; copy the physical file once unless separate copies were requested.
- Flat destination, same name twice: never overwrite. Compare SHA-256; identical content keeps one copy, different content keeps the existing file and reports the conflict.
- Never delete a source as duplicate cleanup unless deletion was explicitly requested.

## Status vocabulary

Keep these distinct in the manifest: exact match, confirmed alias (record which rule), missing file, ambiguous candidate, excluded by type or scope. Only exact and confirmed-alias rows count as found for copying and for yellow marking.
