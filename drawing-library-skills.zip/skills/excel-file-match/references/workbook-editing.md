# Workbook copy, marking, and new records

## Route

Load the `office-xlsx` skill and use its authoring route with the bundled Python from `load_workspace_dependencies` (`openpyxl` is present). Do not install packages, and do not convert the workbook to another format to make editing easier.

Read the source with `load_workbook(path)`, edit in memory, save to a **new** path. The source file is never written.

## Preservation, and one real trap

- Keep every sheet, formula, merged range, column width, conditional format, and unrelated style.
- If an identifier cell holds a formula, do not replace the formula with a value. Mark the row and report that the alias text could not be corrected there.
- `.xls` cannot be edited losslessly by openpyxl. Do not silently convert: ask whether an `.xlsx` output copy is acceptable.
- **Verify that existing drawings survive the round-trip.** `openpyxl` is not dependable at preserving images and shapes embedded in a workbook. If the source already contains 截面图 pictures, test on a copy and compare the image count before trusting the result. If images are lost, stop and tell the user rather than delivering a workbook whose pictures disappeared.

## Mark found identifiers

Apply the fill to the identifier cell only:

```python
from openpyxl.styles import PatternFill
ws.cell(row=r, column=3).fill = PatternFill(
    start_color='FFFFFF00', end_color='FFFFFF00', fill_type='solid')
```

- Yellow means found only if the user says so; only then clear yellow from unmatched identifier cells in that column.
- Preserve non-yellow fills. Never colour the whole row.
- Correct a confirmed alias to the matched file's exact stem only when asked, writing it as text so leading zeros and hyphens survive.

## New records

One row per distinct confirmed project/mold pair present in the files but absent from the workbook.

Map by existing headers; respect unit suffixes in the header text (总宽（mm）, 总高（mm）):

- 项目号, 模具编号, 材质 — read from the printed title block, the drawing notes, or reliable drawing text. Never infer material from the profile's appearance or from the project name.
- **项目号 stays ASCII.** Take the leading ASCII run of the mould number after dropping its trailing serial: `CN2337-12` → `CN2337`, `XL-DJ2015-05` → `XL-DJ2015`, `DJ2332后侧吊耳右型材` → `DJ2332`. Never let a drawing name become a project code; a Chinese project号 is a data error even when the mould number legitimately has Chinese in it.
- **模具编号 may contain Chinese**, and so may the source file name. A sheet with no printed drawing number is identified by its printed name, so `DJ2332前横梁型材` is a valid mould number — do not transliterate or strip it to make columns look tidy.
- 截面图 — a crop of the actual profile cross-section view, not a full-sheet preview.
- 总宽, 总高 — from explicit overall dimension annotations. Never from pixel measurements, viewport size, or geometric extents.
- Dimensions carry **one decimal place**: store `round(value, 1)` and set the cell's `number_format = '0.0'`. An integer result is still written as a float under that format (`41.0`), so the column reads consistently whether the number came from a printed annotation or from an authorised measurement.
- 型材类型 — only when the drawing states it; not from shape alone.
- 图纸类别 — from the verified files for that record (table below).

Copy the style of an adjacent data row, keep the table structure and formulas intact, and do not add columns the user did not ask for. Leave any unreadable, absent, or contradictory field blank and flag that row.

### 图纸类别

| Files present for the record | Value |
| --- | --- |
| DWG only | `cad` |
| ordinary PDF only | `pdf` |
| DWG + ordinary PDF | `cad+pdf` |
| signed-and-sealed PDF only | `会签版` |
| DWG + signed-and-sealed PDF | `cad+会签` |
| ordinary PDF + signed-and-sealed PDF | `pdf+会签` |
| all three | `cad+pdf+会签` |

A PDF with only a signature or only a seal is ordinary. If either mark is unclear, leave the category blank and flag it.

### Section image

A section image is a **screenshot of the drawing view**, not a crop of the profile outline alone. Cropping to the densest connected region of the sheet reliably drops the dimensions, tolerances, and annotations that make the picture useful. Render the whole view, then cut away only the frame, the title block, and the long specification paragraph.

- For a DWG, export DXF and render it. The renderer must expand `DIMENSION` entities — see the `autocad-automation` skill, because a dimension draws itself through an anonymous `*D` block and a naive reader produces a picture with no dimensions at all.
- For a PDF, render the page and crop the drawing side; rotate a long portrait profile to landscape so it reads in a wide cell.
- Keep the aspect ratio. Never stretch, never redraw geometry.

Fit every picture to one **uniform cell box** so the table stays a table:

```python
from openpyxl.drawing.image import Image as XLImage

CELL_W, CELL_H = 210, 157          # one size for every row
img = Image.open(view_png).convert('RGB')
sc = min(CELL_W / img.width, CELL_H / img.height)
w, h = max(1, int(img.width * sc)), max(1, int(img.height * sc))
canvas = Image.new('RGB', (CELL_W, CELL_H), 'white')
canvas.paste(img.resize((w, h), Image.LANCZOS), ((CELL_W - w) // 2, (CELL_H - h) // 2))
canvas.save(cell_png)

ws.add_image(XLImage(cell_png), f'E{row}')     # picture is already cell-sized
ws.row_dimensions[row].height = CELL_H * 0.75  # every data row the same height
ws.column_dimensions['E'].width = (CELL_W - 5) / 7
```

Padding a picture to the cell size is what makes it "fill the cell" without distortion, and it keeps row heights uniform. Do not vary row height per image: the sheet stops reading as a table.

Setting `img.width`/`img.height` after construction does nothing useful — openpyxl fixes the size in the anchor when the `Image` is built, so the picture keeps its native pixel size and overflows neighbouring rows. Pre-scaling sidesteps the whole problem.

**Then repair the package.** openpyxl writes `xl/drawings/drawing1.xml` and the worksheet's `<drawing r:id>` reference but omits that part's content type from `[Content_Types].xml`. Excel and WPS may then show the file with **no pictures at all**, which looks exactly like "the images were never inserted". Add the override before delivering:

```python
override = ('<Override PartName="/xl/drawings/drawing1.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>')
# insert before </Types> in [Content_Types].xml, rewriting the zip entry
```

Do not verify by reading `ws._images[i].width` back: on load openpyxl reports the media's pixel size, not the display size. Check `xl/drawings/drawing1.xml` for one `<ext cx=... cy=.../>` per picture (EMU, 9525 per pixel), and confirm the content-type override exists.

### Lock the picture inside its cell

openpyxl can only create a **floating** picture: it sits on top of the grid, can be dragged anywhere, and by default only moves when the cell moves — it does not resize with it. Users read that as "the picture is not in the cell". A cell-sized picture is not enough either; it will spill into the next row as soon as the row is resized.

Fix the placement after openpyxl has written the file, using Excel itself when it is installed:

```powershell
foreach ($s in $ws.Shapes) {
    $cell = $s.TopLeftCell
    $s.Left   = $cell.Left + 1
    $s.Top    = $cell.Top + 1
    $s.Width  = $cell.Width - 2      # 1pt inset for the border
    $s.Height = $cell.Height - 2
    $s.Placement = 1                 # xlMoveAndSize: move AND size with the cell
}
$wb.Save()
```

Sizing in points from `$cell.Width` / `$cell.Height` beats converting pixels by hand: the picture ends up exactly inside the cell whatever the column width and row height are. Then verify per shape: `TopLeftCell.Column` equals the picture column, `Placement` equals 1, and `Left/Top/Width/Height` stay inside the cell bounds.

Excel COM is Windows-with-Excel only. Without it, say plainly that pictures will float and be draggable, instead of claiming they are embedded in the cell.

### Saving into a file the user has open

`workbook.save()` raises `PermissionError` when Excel holds the target. Do not lose the run: write to `<target>.building.xlsx`, then `os.replace` with a few retries; if it still fails, deliver as `<target>_新.xlsx` and say so. Verify writability with `open(target, 'r+b')` before choosing the path, so the failure is detected up front rather than after minutes of rendering.

## Copy rule for signed PDFs

A PDF with a visible signature **and** a seal gets `会签` appended to its destination copy's stem, before the extension. The source filename is untouched.

`drawing-split` already applies that suffix when it splits such a page, so a stem ending in `会签` is the normal input here: keep it exactly as it is and never append a second one. Only add the suffix when the incoming file lacks it.

## Verify

Reopen the saved workbook and read the changed cells back: fills, values, image anchors, row heights. Compare formula counts and image counts against the source copy. Reconcile yellow cells against the manifest, confirm the destination file set, and confirm the source workbook hash is unchanged.
