"""Report what this machine can actually do for drawing work.

Run once per session before promising anything about DWG or PDF handling.
Prints a capability table; never raises on a missing tool.
"""
import importlib.util
import os
import shutil
import subprocess
import sys


def find_autocad():
    found = []
    for base in (r'C:\Program Files\Autodesk', r'C:\Program Files (x86)\Autodesk'):
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base), reverse=True):
            exe = os.path.join(base, name, 'accoreconsole.exe')
            if os.path.isfile(exe):
                found.append((name, exe))
    return found


def module(name):
    return importlib.util.find_spec(name) is not None


def soffice():
    exe = shutil.which('soffice')
    if exe:
        return exe
    for p in (r'C:\Program Files\LibreOffice\program\soffice.exe',
              r'C:\Program Files (x86)\LibreOffice\program\soffice.exe'):
        if os.path.isfile(p):
            return p
    return None


def main():
    print('== AutoCAD ==')
    cad = find_autocad()
    if cad:
        for name, exe in cad:
            print(f'  ok    {name}: {exe}')
    else:
        print('  MISS  no accoreconsole.exe under Program Files\\Autodesk')

    print('== PDF ==')
    for name in ('fitz', 'pypdf', 'pdfplumber'):
        print(f'  {"ok" if module(name) else "MISS":5} {name}')

    print('== Spreadsheet / imaging ==')
    for name in ('openpyxl', 'pandas', 'PIL'):
        print(f'  {"ok" if module(name) else "MISS":5} {name}')

    print('== LibreOffice ==')
    exe = soffice()
    print(f'  {"ok" if exe else "MISS":5} {exe or "soffice not found"}')

    print(f'== Python ==\n  {sys.executable}')
    print(f'== CWD ==\n  {os.getcwd()}')


if __name__ == '__main__':
    main()
