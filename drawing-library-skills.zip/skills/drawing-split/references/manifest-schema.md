# Manifest schema

`拆分清单.csv` in the output directory, UTF-8 with BOM, comma-separated, one row per delivered file. Other skills read this file as the authoritative list of identifiers and files, so the column names are fixed.

The header row is part of the contract. Do not rename a column to something more descriptive (`图号` → `图号/名称`) even if it reads better: a consumer that looks up `图号` raises `KeyError`, and the failure surfaces far from its cause. Consumers should read by exact name and fail loudly on a missing column rather than silently mapping by position.

| Column | Type | Rule |
| --- | --- | --- |
| `源文件` | text | Source file name, exactly as on disk |
| `图幅序号` | integer | 1-based position of the sheet inside that source |
| `图号` | text | Identifier as printed. Drawing name when no number is printed. Empty only when the sheet is in review |
| `输出文件名` | text | Delivered file name including extension |
| `实体数` | integer | DWG entity count, or 1 for a single-page PDF |
| `切割区域` | text | `(x1, y1) - (x2, y2)` in drawing units, or `page N` / `crop (x1, y1) - (x2, y2)` for PDF |
| `状态` | text | One of the four values below |
| `备注` | text | Short reason for anything not `已核对`; empty otherwise |

`状态` values:

- `已核对` — identifier verified against the printed title block, content checked.
- `复核` — delivered but needs a human decision (no printed number, name used instead, identifier series mismatch).
- `冲突` — duplicate or revision conflict; suffix applied, which copy is authoritative is unknown.
- `跳过` — intentionally not split (single-page input, excluded format, unreadable file).

Invariants the producing run must hold:

1. Every row's `输出文件名` exists in the output directory.
2. `输出文件名` values are unique case-insensitively.
3. A row with `状态 = 已核对` has a non-empty `图号` that appears inside the delivered file.
4. Counts reconcile: `Σ 实体数` plus the enumerated exclusions equals the source total, or the report states why not.
