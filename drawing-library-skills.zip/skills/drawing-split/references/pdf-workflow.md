# PDF workflow

Use a page-level PDF library. With PyMuPDF, page extraction preserves vector geometry, text, and scan quality; re-rendering a page to an image and wrapping it in a new PDF does not.

## 1. Inventory

For each file: page count, page size, rotation, encryption (`is_encrypted`, `needs_pass`), and signature status (`get_sigflags()`; 3 means a signature field is present). Record the SHA-256 of each source.

Note the coordinate system before cropping: PDF space has its origin at the top-left with y increasing downward, the opposite of CAD. A rectangle read from a CAD or a visual estimate must be converted, not copied.

## 2. Map pages to drawings

- Render each page or its title-block corner at a readable DPI and read the printed drawing number visually. Extracted text alone is not trustworthy for scanned sheets or for numbers split across several text runs.
- Preserve the printed number exactly: prefix, letters, separators, leading zeros. Sheet order inside a PDF may not follow the numbering, and one file may mix series.
- A page with several distinct drawings without borders: find each title block, group the nearby views, dimensions, and notes into that anchor, and verify clear whitespace between groups. Crop only when the grouping is unambiguous; otherwise stop that page for review.
- A page stamped 作废 / 不用 / OBSOLETE, or scored through with a diagonal or full-width stroke, is **not split**. Record it in the manifest with `状态 = 跳过` and the reason, and list it separately in the report. On a scan this is visual only — there is no text layer to match, so look at the page instead of grepping it.

## 3. Extract

```python
import fitz

src = fitz.open(src_path)
for i in range(src.page_count):
    out = fitz.open()
    out.insert_pdf(src, from_page=i, to_page=i)   # original page object, not a bitmap
    page = out[0]
    # optional: crop to a verified region, still vector-preserving
    # page.set_cropbox(fitz.Rect(x0, y0, x1, y1))
    out.save(dest_path, garbage=3, deflate=True)
    out.close()
```

- `insert_pdf` keeps vector content, text, images, page size, and visible stamps.
- `set_cropbox` changes the visible region without rasterizing. Verify the crop visually; content outside the box is still in the file.
- Skip one-page files by default; they are already one sheet.
- Report signature invalidation instead of promising the signature survives extraction.

## 4. Naming and collisions

Name from the printed drawing number, else the drawing name. Keep the output flat. Never overwrite: compare case-insensitively and add `_2`, recording the collision.

**Signed-and-sealed pages carry the `会签` suffix.** A page that visibly shows both a signature and a seal is delivered as `<drawing number>会签.pdf` — suffix at the end of the stem, before the extension. This is a naming convention, not a revision label:

- Both marks present → append `会签`.
- Only a signature, or only a seal → ordinary name, no suffix.
- The stem already ends with `会签` → leave it alone; never append twice.
- Any other label (`图纸`, `批准`, `最终版`) → only when the user explicitly asks for it.

Record in the manifest that the suffix came from a visual signature-and-seal check, and say in the report that the marks are page pixels, not a digital signature.

## 5. Verify

Reopen every output: exactly one page, expected page size and orientation. Render each and compare against the corresponding source page for title block, dimensions, notes, seals, and handwritten marks. Confirm filenames against the visual title block, not against page order. Report skipped single-page files, ambiguous multi-drawing pages, encrypted or unreadable files, and signature limitations separately.

A cheap, strong check on a scanned set: render the output page and the source page at the same DPI and compare the pixel buffers. Identical buffers prove nothing was re-encoded, cropped, or re-oriented on the way out. This is how a three-page signed set was confirmed after splitting (order 01, 03, 02 on the pages, correctly named from the title blocks).

Scanned sheets carry no text layer, so `get_text()` returning empty is normal, not a failure: read the printed number from the title block visually and record that you did. `get_sigflags()` returning `-1` means there is no signature *field*; a red seal and an ink signature are page pixels and survive extraction untouched. Say exactly that instead of claiming a digital signature was preserved.
