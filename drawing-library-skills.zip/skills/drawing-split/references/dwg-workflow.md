# DWG workflow

Geometry decisions happen outside AutoCAD. Use the console only to read and write drawings; use DXF plus a script for measurement, clustering, and naming. Attempting to plan sheet boundaries with `ssget` inside the console is slow and unreliable.

Read the `autocad-automation` skill before the first console call: it carries the console's failure modes, the mandatory `ZOOM`/`REGEN` before selection, the copy-then-erase split recipe, and the encoding rules.

## 1. Inventory without modifying anything

1. Copy each source into your workspace and record its SHA-256.
2. Export DXF once per source `(command "_.DXFOUT" path "16")` and parse it. From the DXF you get entity types, layers, all text with insertion points, closed polylines, and `INSERT` names with block contents.
3. List layers with `70` (frozen) and `62` (off). A frozen layer silently removes entities from later selection.

## 2. Find the sheets

Frames are frequently **four `LINE` segments**, not closed polylines. Detect both:

- Collect horizontal segments (equal y) and vertical segments (equal x).
- For a candidate rectangle: two horizontal segments with the same x-span, plus vertical segments at both ends spanning that y-range.
- Also accept closed `LWPOLYLINE` rectangles.

Then filter, in this order:

1. Drop candidates that contain no title-block anchor text (drawing number, drawing name, or title-block field labels).
2. Drop candidates contained inside another kept candidate (inner borders, title-block cells). Use a small tolerance, around 0.5% of the shorter side.
3. Keep the remaining outermost rectangles as sheets.

Do not hardcode a minimum sheet size in drawing units: drawings use different scales and sheet sizes. Size follows from the containment filter plus the anchor requirement.

If no rectangle survives, fall back to frameless inference: cluster entities and text by proximity, anchor each cluster on a unique title block or name note, and separate clusters at their whitespace gutters. If two clusters could share an entity, stop that sheet for review instead of cutting through it.

## 3. Assign content and set the cut region

- Assign each entity to the sheet whose rectangle contains its bounding-box centre.
- Grow every sheet rectangle by about 0.5% of its shorter side (minimum one unit) so border lines lying exactly on the frame are included.
- Assert the grown regions do not overlap. If two overlap, shrink both to the midpoint of the gap and re-check.
- Report entities that belong to no region instead of silently dropping them. In practice these are invisible stray points and origin junk; state the count and what they are.

## 3b. Sheets that must not be split

A sheet is excluded from splitting — not deleted, not renamed, just skipped and recorded — when either signal is present:

1. **Explicit void text**: 作废, 不用, 取消, 废弃, 报废, 仅供参考, DO NOT USE, VOID, OBSOLETE anywhere in the sheet. This is high confidence: record it and skip.
2. **A stroke crossing the whole framed view**: a diagonal running corner to corner, or a horizontal/vertical line crossing the view between opposite borders. This mark means the drawing is superseded.

Signal 2 is **candidate-only, never automatic**. Measured on real sets, naive length tests flag every sheet, because these all look like full-width strokes:

| Looks like a crossing stroke | Why it is not |
| --- | --- |
| The frame itself | Its four sides span the full width/height by definition |
| The inner border of a double frame | Same, inset by 2–8% |
| A long horizontal dimension line | Spans the profile and often the whole sheet; it is annotation, not a strike-through |
| A leader or a centre line | Runs a long way but leaves the border untouched |

So: detect candidates, then **render the sheet and look at it**. A genuine void stroke visibly crosses the profile outline and is not decorated with arrowheads, dimension text, or extension lines. Record the decision and its evidence either way.

When a sheet is skipped, the manifest gets one row with `状态 = 跳过`, the identifier if one is legible, and `备注` naming the reason (`图面标注作废` / `斜线贯穿` / `横线贯穿`) plus whether it was confirmed visually. The report lists skipped sheets separately from failures: a skipped sheet is a correct outcome, not an error.

## 4. Write one file per sheet

Follow the `autocad-automation` split recipe: copy the source, open the copy, select the region window, remove those handles from `(ssget "_X")`, erase the remainder, save, quit. One process per output file. Never `QSAVE` a source, and guard the run so an empty window cannot empty a file.

Write each output under an ASCII temporary name, then rename from the driving language. Chinese filenames must not travel through the console's command line or script files.

## 5. Read identifiers

- Take the drawing number from the title block, exactly as printed.
- The number may live in a block attribute rather than model-space text: walk `entnext` while the type is `ATTRIB`, and expand block definitions when scanning `INSERT`s.
- `MTEXT` values carry formatting runs such as `{\fSimSun|b0|i0|c134|p49;CN2337-09}`. Strip braces and `\f...;`/`\P`/`\C...;` before matching.
- Distinguish the drawing number from the material code, the standard number, the weight, and the sheet counter. Nearby text is not evidence for the identifier.
- If the title block has a `图号` label with an empty value, fall back to the drawing name printed beside it.

## 6. Verify

Per output, reopen and assert: entity count > 0, the expected identifier present, no sibling identifier present. Across all outputs, reconcile counts against the source total and enumerate exclusions. Re-hash sources. Then render previews and look at representative and exceptional sheets for clipping.

Entity-count sums are a strong signal: a missing sheet, a double-assigned region, or an over-wide window all show up as a mismatch before anyone looks at a picture.
