---
name: drawing-split
description: Split a multi-sheet DWG or PDF drawing set into one file per sheet, named from the printed drawing number or drawing name, into a flat output folder. Use when a combined CAD or PDF set must become one drawing per file, and when sheets must be found without drawn frames.
---

# Split a drawing set

Four phases, in order: **probe → decide → execute → verify**. Do not skip the probe, and do not report completion without the verify assertions.

## 1. Probe

Run `scripts/probe_env.py` once per session. It reports the AutoCAD console path and version, available PDF libraries, and whether a spreadsheet/LibreOffice route exists.

- A missing capability is a finding, not a reason to invent an API. Say what is missing and offer the closest route.
- DWG work needs a working `accoreconsole`; PDF work needs a page-level PDF library. If neither is present for the requested format, stop and ask.
- Read [references/dwg-workflow.md](references/dwg-workflow.md) or [references/pdf-workflow.md](references/pdf-workflow.md) for the matching format before executing.

## 2. Decide

Confirm from the request, not from habit: input scope, output directory, recursion, included formats, and whether single-page files should be collected. Defaults when unstated: one flat output directory, no recursion, skip one-page PDFs, sources read-only.

Then classify every sheet:

| Situation | Action |
| --- | --- |
| Drawn frame, unambiguous | Use it. Split, do not ask. |
| Frameless, one clear anchor (title block, drawing number, name note) | Infer the region from the anchor plus its grouped views and whitespace gutters. Split, and record the virtual boundary in the manifest. |
| Frame candidate that is really a title-block cell or a detail rectangle | Reject it. A sheet must contain a title-block anchor and must not be a small rectangle nested inside a larger one. |
| Several anchors conflict, or content could belong to either neighbour | Stop that sheet only. Continue with the rest, list it for review. |
| No drawing number, but a clear drawing name | Use the printed name as the filename stem. Flag it in the manifest. |
| No number and no reliable name | Leave it in review. Never invent an identifier. |
| Same identifier on two sheets | Compare relative geometry: identical extents and texts means a true duplicate (report, do not dedupe unless asked); different geometry means a revision conflict (suffix `_2`, flag as "confirm which is authoritative"). |
| Sheet marked 作废 / 不用 / 取消 / 废弃 / OBSOLETE | **Do not split it.** Record one manifest row with `状态 = 跳过`, the reason, and the evidence. Keep the source untouched and say so in the report. |
| A straight stroke (diagonal, or horizontal/vertical) crossing the whole framed view | Treat as a void mark and **do not split**. Confirm it visually first — see the false-positive rules in [references/dwg-workflow.md](references/dwg-workflow.md). Record `状态 = 跳过` with the stroke's kind and position. |

Ask at most **one** consolidated question, after the batch, with your default decision stated for each ambiguous item. Do not stop the run to ask one question per sheet.

Naming rules, in priority order: the printed drawing number exactly as printed (prefix, letters, separators, leading zeros preserved); else the printed drawing name; else review. Never derive an identifier from the source filename, page index, a detail callout, a material code, or a standard number. One suffix is part of the naming convention rather than a label: a sheet that visibly carries **both a signature and a seal** gets `会签` at the end of the stem (`DK2406-01会签.pdf`). Never append it twice, and do not invent other labels.

## 3. Execute

- **DWG:** load the `autocad-automation` skill and follow it. Compute the sheet regions in geometry (DXF + Python), not by eye in the console; use AutoCAD only to write the files. Keep the plan in a table before writing anything.
- **PDF:** follow [references/pdf-workflow.md](references/pdf-workflow.md). Copy original page objects; never rasterize a page and re-wrap it.
- Work on copies. No output may overwrite an existing file: resolve collisions deterministically with `_2`, `_3`, and record every collision.
- Write progress after each sheet, so an interrupted run can resume without redoing finished work.

## 4. Verify

Run these assertions on the delivered files, not on an intermediate plan:

1. Every output opens and has content (entity count > 0, or page count == 1).
2. The identifier printed inside each output matches its filename; no sibling sheet's identifier appears in it.
3. Sum of per-output counts reconciles with the source total, and every excluded object is enumerated in the manifest.
4. Source files are byte-identical to before the run (SHA-256).
5. Filenames are unique case-insensitively and contain no Windows-forbidden characters.

Then inspect previews of representative and exceptional sheets and confirm nothing is clipped. Do not claim a check you did not perform.

## 5. Deliver

Write `拆分清单.csv` in the output directory using the schema in [references/manifest-schema.md](references/manifest-schema.md). Report: sources examined, sheets produced, skipped/ambiguous items, collisions, excluded objects, and the output path.

Downstream skills consume this manifest as the authoritative identifier list, so the schema is a contract: keep the column names and one row per output file.
