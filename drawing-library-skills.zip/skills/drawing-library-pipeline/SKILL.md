---
name: drawing-library-pipeline
description: End-to-end pipeline for turning drawing sets into a maintained profile library - split multi-sheet DWG/PDF into single drawings, check them against the library catalogue, add the missing records and files, refresh the library workbook, and prove each handoff. Use when a batch of drawings must be filed into an existing library rather than merely split.
---

# From drawing set to library record

Four skills, used in a fixed order, with one artifact carrying each handoff. Do not start stage N+1 until stage N's gate passes: every failure this pipeline prevents is a mismatch between a file and a record, and those are cheap to catch at the boundary and expensive to find later.

| Stage | Skill | Consumes | Produces |
| --- | --- | --- | --- |
| 0. Probe | `drawing-split` (`scripts/probe_env.py`) | — | capability matrix |
| 1. Split | `drawing-split` | DWG/PDF sets | single drawings + `拆分清单.csv` |
| 2. Audit | `library-audit` | split drawings + catalogue `.xls` + `型材图库` | `拆分文件对照报告.csv` |
| 3. Repair | `library-audit` | audit findings | new catalogue rows + files in `型材图库` |
| 4. Register | `excel-file-match` | split drawings + workbook template | filled workbook |
| 5. Deliver | this skill | all artifacts | report + invariant proof |

Mechanics live in `autocad-automation`; load it before any console or COM work.

## 0. Probe

Report what the machine can and cannot do before promising anything. A missing `accoreconsole` stops DWG work; a missing Excel COM stops any catalogue edit; a missing PDF library stops page extraction. Say which stage is blocked, not "something failed".

## 1. Split

One sheet per file, named from the printed drawing number — never from the source filename or page order. Frameless sets are cut at whitespace gutters, not skipped. Sheets marked 作废 / crossed through are **not** split and are reported instead.

Gate: entity totals reconcile with the source, every output carries only its own identifier, sources are hash-identical afterwards.

## 2. Audit before writing anything

Match each delivered drawing against the catalogue: exact identifier, then same number without a prefix, then measured dimensions within the same project (0.5 mm). Never force a hit.

Gate: every drawing is classified as present or absent, with evidence, and orphans are classified (bundle / index / backup), not guessed.

## 3. Repair the gaps

For each absent drawing: back up the catalogue, copy the file into `型材图库`, append the row, save, re-verify. The order makes a crash leave an orphan file rather than a row pointing at nothing.

Gate: the catalogue grew by exactly the number of repairs, and no row lacks a file.

## 4. Register in the workbook

Keep 项目号 ASCII, 模具编号 may carry Chinese, dimensions one decimal, pictures locked inside their cells (`xlMoveAndSize`), and the layout copied from the library the user actually uses.

Gate: reopening the workbook shows the expected row count and one picture per row, all confined to their cells.

## 5. Deliver

Report five numbers: drawings delivered, drawings already in the library, rows added, files copied, violations remaining. Then state the invariant explicitly — "629 catalogue rows, 0 without a file" — because a silent zero is the only proof that the chain is intact.

## Non-negotiables across every stage

- Sources are read-only; nothing is written back to a delivered original.
- No stage overwrites an existing file or row; collisions get a suffix and a note.
- Every identifier comes from the printed title block, never inferred.
- A skipped sheet, an orphan, or a blank field is a finding to report — never a guess to hide.

## References

- [references/handoffs.md](references/handoffs.md) — the artifact each stage must emit, and its required columns.
- [references/case-2026-11.md](references/case-2026-11.md) — the executed job this pipeline was distilled from, with its real counts and the traps it hit.
