# Handoff artifacts

Every stage writes one file that the next stage reads. Fixed names and fixed columns: a downstream step that has to guess a column name is a bug waiting to surface far from its cause.

All CSVs are UTF-8 **with BOM** (Excel needs it for Chinese), comma-separated, one row per item.

## 1. `拆分清单.csv` — written by the split stage

Lives in the split output directory.

| Column | Content |
| --- | --- |
| `源文件` | Source file name exactly as on disk |
| `图幅序号` | 1-based sheet index inside that source |
| `图号` | Printed identifier, or the printed drawing name when no number exists |
| `输出文件名` | Delivered file name including extension |
| `实体数` | DWG entity count, or 1 for a single-page PDF |
| `切割区域` | `(x1, y1) - (x2, y2)` in drawing units, or `page N` |
| `状态` | `已核对` / `复核` / `冲突` / `跳过` |
| `备注` | Why it is not `已核对`; empty otherwise |

Consumers read `图号` and `输出文件名`. Do not rename these columns to something more descriptive — a rename caused a `KeyError` in exactly this pipeline.

## 2. `拆分文件对照报告.csv` — written by the audit stage

| Column | Content |
| --- | --- |
| `输出文件名` | Drawing being checked |
| `我方图号` | Identifier from the split manifest |
| `来源目录` | Which split batch it came from |
| `库中是否存在` | `是` / `否` |
| `匹配方式` | `编号精确` / `编号前缀差异` / `尺寸匹配` / empty |
| `库中行号` | Row in the catalogue |
| `库中项目号`, `库中模具编号`, `库中材质` | Catalogue values |
| `我方材质`, `库中总宽`, `库中总高`, `库中图纸类别` | For comparison |
| `说明` | Prefix difference, dimension evidence, or material conflict |

`库中是否存在 = 否` is the repair list; it must be empty before the register stage.

## 3. `库目录对账报告.csv` — written by the invariant check

| Column | Content |
| --- | --- |
| `类型` | `表格有图库无` / `图库有表格无` |
| `Excel行号`, `模具编号`, `项目号`, `图纸类别` | Catalogue side |
| `图库文件` | File side |

`表格有图库无` must be zero after a repair. `图库有表格无` may be non-zero and is expected to contain only bundles, catalogues, and backups — each one named in the report.

## 4. The library workbook

One sheet, title in row 1 (merged across the header width), header in row 2, data from row 3. Columns: 序号, 项目号, 模具编号, 材质, 截面图, 总宽（MM）, 总高（MM）, 型材定尺MM, 型材物料编码, 图纸类别, 模具是否可以正常使用, 模具存放地, 模具设计是否兼容挤压机通用化, 型材类型, 备注.

Section pictures are anchored in 截面图, sized to the cell, and locked with `Placement = xlMoveAndSize`.

## What never gets renamed

`图号`, `输出文件名`, `模具编号`, `库中行号`. These four are cross-referenced by later stages; everything else is descriptive and may be extended.
