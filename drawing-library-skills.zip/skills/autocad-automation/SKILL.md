---
name: autocad-automation
description: Drive AutoCAD on Windows headlessly with accoreconsole and AutoLISP to inspect, split, filter, convert, and verify DWG/DXF drawings. Use for any task that must read DWG content, extract sheets, export DXF or PDF, or batch-edit drawings.
---

# AutoCAD automation

Drive the installed AutoCAD through its headless core console (`accoreconsole.exe`) and AutoLISP. Do not script the GUI, and do not assume a DWG library exists in Python: on this platform `accoreconsole` is the only reliable reader and writer.

Read [references/accoreconsole-quirks.md](references/accoreconsole-quirks.md) before the first run in a session, and [references/lisp-recipes.md](references/lisp-recipes.md) when writing the extraction code.

## 1. Locate the toolchain

- Find `accoreconsole.exe` under `C:\Program Files\Autodesk\AutoCAD <year>\`. Run it with the install directory as the working directory and absolute paths for `/i` (input DWG) and `/s` (script).
- Record the version it reports. In this environment AutoCAD 2027 reports `ACADVER` `26.0`, DXF version `AC1032`, and drawing code page `ANSI_936`.
- The console needs a normal user token. Under a restricted file sandbox it dies with exit code `0xC06D007E` (`-1066598274`, delay-load module not found) before running any LISP. If you see that code, ask for full access instead of debugging the script.

## 2. Non-negotiable rules

- Never let AutoCAD write to a source drawing. Copy it first, and only `QSAVE`/`SAVEAS` on a copy you own.
- Keep every path inside `.lsp`/`.scr` ASCII and use forward slashes. Do Unicode paths and filenames from the driving language (Python is Unicode-safe), or split into an ASCII temp name and rename afterwards.
- Write `.lsp` files as **GBK/ANSI** bytes. They are read as ANSI, not UTF-8.
- End every script with `(command "_.QUIT" "_N")`. Without it the process can hang forever after `WBLOCK`, `-PLOT`, or a cancelled prompt.
- Set `FILEDIA` 0, `CMDDIA` 0, `CMDECHO` 0, `EXPERT` 5, `OSMODE` 0 at the top.
- One destructive job per process. Sequential `WBLOCK` calls in one session became unreliable in testing; reopening the file fresh is cheap and deterministic.
- Verify by reopening every output. A zero-entity file, a missing drawing number, or a neighbour's content is a failure even if the process exited 0.

## 3. Session pattern

Write two files and run them: a `.scr` whose only job is to load the `.lsp`, and the `.lsp` that defines and then calls your functions.

```
; script.scr
(load "C:/work/task.lsp")
```

```lisp
; task.lsp
(setvar "FILEDIA" 0)(setvar "CMDDIA" 0)(setvar "CMDECHO" 0)(setvar "EXPERT" 5)(setvar "OSMODE" 0)
(command "_.ZOOM" "_E")(command "_.REGEN")
(setq ss (ssget "_W" (list 1130.0 -233.0) (list 1398.0 -43.0)))
(setq f (open "C:/work/report.txt" "w"))
(write-line (itoa (if ss (sslength ss) 0)) f)
(close f)
(command "_.QUIT" "_N")
```

Read the result from the report file, not from stdout: the console redirects and re-encodes stdout, so parsed console text is unreliable.

## 4. What the core console cannot do

- **No ActiveX.** `vlax-get-acad-object` returns `nil`, so every `vla-*` call and `layoutlist` fails and silently aborts the rest of the function. If a script stops writing output halfway, suspect this first. Use only `entget`/`ssget`/`tblnext`/`tblsearch`.
- **Selection is view-bound until regenerated.** `ssget "_W"`/`"_C"` returns `nil` for regions outside the current view right after a drawing opens. Always `(command "_.ZOOM" "_E")` then `(command "_.REGEN")` before selecting.
- **`-PLOT` prompts are not enumerable.** Paper-size names live in a compressed `.pc3`, and a wrong answer leaves the console waiting. Prefer exporting DXF and rendering it yourself; only plot when a PDF is genuinely required, and give every prompt explicitly.

## 5. Extraction and editing recipes

- **Inventory:** `ssget "_X"` plus a type×layer tally, every `TEXT`/`MTEXT` value with its insertion point, closed `LWPOLYLINE` extents, and `INSERT` names. This is enough to find title blocks without plotting.
- **Frame detection:** sheet borders are often four `LINE`s, not closed polylines. Pair horizontal segments that share an x-span, then require vertical segments joining them; also accept closed `LWPOLYLINE`s. Keep only outermost rectangles.
- **Split one sheet:** copy the DWG to the target, open the copy, `(ssget "_W")` the sheet window, remove those handles from `(ssget "_X")` with `ssdel`, `ERASE` the remainder, `QSAVE`. This is deterministic and never touches the source, unlike `WBLOCK`. Guard with `(if w ... (write-line "0" f))` so an empty selection can never empty a file.
- **Geometry for analysis:** `(command "_.DXFOUT" path "16")`. The accuracy argument is mandatory; omit it and the console waits at a prompt.
- **Layer state:** read flags with `tblnext` (`70` frozen, `62` off) before assuming `ssget` can see everything.

## 6. Text and encoding

- `write-line` emits ANSI (GBK here). Decode reports as GBK; UTF-8 decoding produces mojibake.
- Strip `\r`, `\n`, and `\t` out of drawing text before writing a tab-separated report, or one multi-line `MTEXT` breaks every downstream column.
- `(cadr dotted-pair)` is always `nil`. For a `(key . value)` pair read `(cdr pair)`; this mistake aborts the function at `strcat`.
- MTEXT carries formatting runs such as `{\fSimSun|b0|i0|c134|p49;CN2337-09}`. Strip the braces and `\f...;`/`\P`/`\C...;` before matching drawing numbers.
- Drawing numbers live in the title block, sometimes as block attributes rather than model-space text. Walk `entnext` from `INSERT` while the entity type is `ATTRIB`, and expand block definitions when reporting.
- Preserve the printed number exactly: prefix, letters, separators, leading zeros. Never derive it from the file name, page order, or a nearby callout.

## 7. Verification

For each output:

1. Reopen it in a fresh `accoreconsole` and count entities.
2. Dump its text and confirm exactly its own drawing number is present and no sibling's number leaked in.
3. Compare the total of all outputs against the source count, accounting for deliberately excluded objects (stray points, off-sheet junk).
4. Render a preview and look at it when the layout matters. A minimal DXF line renderer over `LINE`/`ARC`/`CIRCLE`/`LWPOLYLINE`/`ELLIPSE`/`SOLID`/`INSERT` is enough to judge whether a sheet is complete and un-clipped.
5. Re-hash the sources and report that they are unchanged.
