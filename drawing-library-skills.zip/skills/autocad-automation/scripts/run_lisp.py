"""Run an AutoLISP file against a DWG in AutoCAD's headless core console.

Usage:
    python run_lisp.py --dwg drawing.dwg --lisp task.lsp [--timeout 180]

The LISP file must end with (command "_.QUIT" "_N"); without it the console can
hang. Paths handed to AutoCAD are always ASCII with forward slashes, so the DWG
and LISP are staged under ASCII names in a temp directory and the real paths are
never passed through the console layer.
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile


def find_console():
    for base in (r'C:\Program Files\Autodesk', r'C:\Program Files (x86)\Autodesk'):
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base), reverse=True):
            exe = os.path.join(base, name, 'accoreconsole.exe')
            if os.path.isfile(exe):
                return exe, os.path.dirname(exe)
    raise SystemExit('accoreconsole.exe not found under Program Files\\Autodesk')


def run(dwg, lisp, timeout=180):
    exe, home = find_console()
    with tempfile.TemporaryDirectory(prefix='acad_') as work:
        staged_dwg = os.path.join(work, 'in.dwg')
        staged_lsp = os.path.join(work, 'task.lsp')
        script = os.path.join(work, 'task.scr')
        shutil.copyfile(dwg, staged_dwg)
        shutil.copyfile(lisp, staged_lsp)
        with open(staged_lsp, 'rb') as f:
            body = f.read()
        # The console reads scripts as ANSI; re-encode so a UTF-8 LISP file still works.
        text = body.decode('utf-8', errors='replace')
        with open(staged_lsp, 'wb') as f:
            f.write(text.encode('gbk', errors='replace'))
        with open(script, 'w', encoding='ascii') as f:
            f.write('(load "%s")\n' % staged_lsp.replace('\\', '/'))
        try:
            proc = subprocess.run([exe, '/i', staged_dwg, '/s', script], cwd=home,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  timeout=timeout)
            return proc.returncode
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/F', '/IM', 'accoreconsole.exe'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return 'timeout'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dwg', required=True)
    ap.add_argument('--lisp', required=True)
    ap.add_argument('--timeout', type=int, default=180)
    args = ap.parse_args()
    rc = run(args.dwg, args.lisp, args.timeout)
    print('exit=%s' % rc)
    return 0 if rc == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
