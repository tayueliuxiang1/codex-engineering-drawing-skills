# AutoLISP recipes

All of these were run against real drawings in AutoCAD 2027 core console. Paths are ASCII with forward slashes; `@OUT@` marks the report path substituted by the driver.

## Report writer and sanitizer

```lisp
(defun w (f k v) (write-line (strcat k "\t" v) f))
(defun san (s) (if s (vl-string-translate (strcat (chr 13) (chr 10) (chr 9)) "   " s) ""))
(defun r3 (x) (if x (rtos x 2 3) "nil"))
```

## Inventory of a drawing

```lisp
(defun c:INSPECT ( / f ss i d)
  (setq f (open "@OUT@" "w"))
  (w f "ACADVER" (getvar "ACADVER"))
  (w f "INSUNITS" (itoa (getvar "INSUNITS")))
  (w f "EXTMIN" (strcat (r3 (car (getvar "EXTMIN"))) "," (r3 (cadr (getvar "EXTMIN")))))
  (w f "EXTMAX" (strcat (r3 (car (getvar "EXTMAX"))) "," (r3 (cadr (getvar "EXTMAX")))))
  (setq ss (ssget "_X"))
  (w f "MCOUNT" (itoa (if ss (sslength ss) 0)))
  (setq i 0)
  (while (and ss (< i (sslength ss)))
    (setq d (entget (ssname ss i)))
    (cond
      ((= (cdr (assoc 0 d)) "TEXT")
        (w f "TEXT" (strcat (san (cdr (assoc 1 d))) "\t"
                            (r3 (car (cdr (assoc 10 d)))) "\t" (r3 (cadr (cdr (assoc 10 d)))))))
      ((= (cdr (assoc 0 d)) "MTEXT")
        (w f "MTEXT" (strcat (san (cdr (assoc 1 d))) "\t"
                             (r3 (car (cdr (assoc 10 d)))) "\t" (r3 (cadr (cdr (assoc 10 d)))))))
      ((= (cdr (assoc 0 d)) "INSERT")
        (w f "INSERT" (strcat (cdr (assoc 2 d)) "\t" (cdr (assoc 8 d))))
        (setq nx (entnext (ssname ss i)))
        (while (and nx (setq nd (entget nx)) (= "ATTRIB" (cdr (assoc 0 nd))))
          (w f "ATTRIB" (strcat (san (cdr (assoc 2 nd))) "\t" (san (cdr (assoc 1 nd)))))
          (setq nx (entnext nx)))))
    (setq i (1+ i)))
  (close f) (princ))
```

Note the `(cdr (assoc 2 nd))` pattern: block attributes are separate `ATTRIB` entities chained after the `INSERT`, not fields inside it.

## Tally of entity type × layer

```lisp
(setq cnt nil)
(setq i 0)
(while (< i (sslength ss))
  (setq d (entget (ssname ss i)))
  (setq cnt (cons (cons (cdr (assoc 0 d)) (cdr (assoc 8 d))) cnt))
  (setq i (1+ i)))
;; count occurrences; sort by frequency
```

Do not write `(cadr (car pair))` when `pair` is `(type . layer)` — that is `nil` and kills the `strcat`.

## Closed polylines as frame candidates

```lisp
(if (setq ss (ssget "_X" '((0 . "LWPOLYLINE"))))
  (progn
    (setq i 0)
    (while (< i (sslength ss))
      (setq d (entget (ssname ss i)))
      (if (= 1 (cdr (assoc 70 d)))
        (progn
          (setq lo (mapcar '(lambda (x) (cdr x)) (vl-remove-if-not '(lambda (x) (= (car x) 10)) d)))
          (w f "FRAME" (strcat (r3 (apply 'min (mapcar 'car lo))) "\t"
                               (r3 (apply 'min (mapcar 'cadr lo))) "\t"
                               (r3 (apply 'max (mapcar 'car lo))) "\t"
                               (r3 (apply 'max (mapcar 'cadr lo)))))))
      (setq i (1+ i)))))
```

Careful: sheets are frequently bordered by four `LINE`s and only some are closed polylines. Combine both detectors, then keep only rectangles not contained in another.

## Split: keep a window, erase the rest (safe form)

```lisp
(setvar "FILEDIA" 0)(setvar "CMDDIA" 0)(setvar "CMDECHO" 0)(setvar "EXPERT" 5)(setvar "OSMODE" 0)
(command "_.ZOOM" "_E")(command "_.REGEN")
(setq w (ssget "_W" (list 3030.1176 -491.7500) (list 3232.1176 -347.7500)))
(setq f (open "@CNT@" "w"))
(if w
  (progn
    (setq a (ssget "_X"))
    (repeat (setq k (sslength w)) (setq k (1- k)) (ssdel (ssname w k) a))
    (setq na (if a (sslength a) 0))
    (if (> na 0) (command "_.ERASE" a ""))
    (command "_.QSAVE")
    (write-line (strcat (itoa (sslength w)) "\t" (itoa na)) f))
  (write-line "0\t0" f))
(close f)
(command "_.QUIT" "_N")
```

Run it once per output file, on a copy. The `ZOOM`/`REGEN` pair is mandatory; without it `ssget "_W"` silently returns `nil`.

## Export DXF for analysis

```lisp
(setvar "FILEDIA" 0)
(command "_.DXFOUT" "C:/work/out.dxf" "16")
(command "_.QUIT" "_N")
```

The `"16"` is the decimal-places answer. Then parse `ENTITIES` and `BLOCKS`: group codes by `0` records, read `10/20` pairs as points, and expand `INSERT` with `(insert - block base) → rotate → scale → translate`. Forget the block base point and geometry scatters away from the drawing.

## What a DXF reader silently loses

Four entity kinds carry their visible geometry somewhere other than their own group codes. A reader that handles only `LINE`/`LWPOLYLINE`/`ARC`/`CIRCLE`/`TEXT` will produce a drawing that looks *plausible but stripped* — usually discovered only after someone asks why the dimensions are missing.

| Entity | Where the geometry is | Symptom if skipped |
| --- | --- | --- |
| `DIMENSION` | group `2` names an anonymous `*D…` block holding the lines, arrows and text, already in WCS — render the block at identity | every dimension disappears; the profile has no measurements |
| `INSERT` | the named block definition, offset by the block's base point | geometry lands in the wrong place, extents explode |
| `ATTRIB` | a separate entity chained after its `INSERT` via `entnext`, code `2` tag and code `1` value | title-block fields vanish, including drawing numbers |
| `HATCH` | boundary path and pattern; solid fills are cosmetic only | sectioned areas look hollow |

Verify a renderer by counting: a sheet with N `DIMENSION` entities must gain several primitives per dimension. If the primitive count equals the entity count, dimensions and blocks are being dropped.

Dimension text may itself be an `ATTRIB` inside the `*D` block, so handle both or the numbers stay missing even after the lines appear.

## Layer state before selecting

```lisp
(setq lt (tblnext "LAYER" T))
(while lt
  (w f "LAYER" (strcat (cdr (assoc 2 lt)) "\t70=" (itoa (cdr (assoc 70 lt)))
                       "\t62=" (itoa (cdr (assoc 62 lt)))))
  (setq lt (tblnext "LAYER")))
```

`70` bit 1 = frozen, negative `62` = off. Do not interleave `-LAYER` commands inside a `tblnext` loop; collect the names first, then act on them.
