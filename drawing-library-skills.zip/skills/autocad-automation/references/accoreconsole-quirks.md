# accoreconsole failure modes

Every row below was observed on AutoCAD 2027 (`ACADVER` 26.0) on Windows. The symptom is what you actually see, which is usually not an error message.

## Process level

| Symptom | Cause | Fix |
| --- | --- | --- |
| Exit `-1066598274` (`0xC06D007E`), banner prints, no LISP runs | Delay-load DLL failure under a restricted token / file sandbox | Run with full access; do not retry under the sandbox |
| Process never returns, output file already written | Script reached the end without `QUIT`, or a command is still prompting | Append `(command "_.QUIT" "_N")`; kill stale `accoreconsole.exe` before rerunning |
| Console text is UTF-16 and mostly empty | stdout is redirected to a temp file by the console itself | Have LISP write a report file and parse that instead of stdout |
| Chinese text in `.lsp` becomes mojibake in output paths or strings | `.lsp` is read as ANSI, not UTF-8 | Write `.lsp` as GBK bytes, or keep LISP strings ASCII-only and rename from the driving language |
| Backslashes in a path break a LISP string | `\` starts an escape (`\t`, `\n`) | Use forward slashes in every path inside LISP |

## AutoLISP level

| Symptom | Cause | Fix |
| --- | --- | --- |
| Report stops mid-file, no error surfaced | A `vla-*` or `layoutlist` call raised and aborted the function | Core console has no ActiveX; remove all `vla-*`, use `entget`/`ssget`/`tblnext` |
| `(vlax-get-acad-object)` returns `nil` | ActiveX unavailable in core console | Same as above |
| `ssget "_W"` returns `nil` for a region that clearly has geometry | Selection is view-bound before the model regenerates | `(command "_.ZOOM" "_E")` then `(command "_.REGEN")` before selecting |
| Tab-separated report has extra columns / parse errors | `MTEXT` value contained a real newline or tab | Sanitize: `(vl-string-translate (strcat (chr 13) (chr 10) (chr 9)) "   " s)` |
| `strcat` fails on a value that looks present | Used `(cadr pair)` on a dotted pair `(key . value)` → `nil` | Use `(cdr pair)` |
| `DXFOUT` hangs at a prompt | Accuracy argument omitted | `(command "_.DXFOUT" path "16")` |
| `-PLOT` hangs at a prompt | Paper-size / device names cannot be enumerated (compressed `.pc3`) | Avoid plotting; export DXF and render yourself |
| Report text is mojibake when decoded as UTF-8 | `write-line` emits ANSI/GBK | Decode as GBK (code page 936) |

## Drawing mutation surprises

`(command "_.WBLOCK" path "" "0,0" ss "")` produced correct new files but in a sequential batch the *source* drawing ended up saved and missing entities (467 KB → 430 KB, entity count dropped), which then made later selections return `nil`. Do not chain `WBLOCK` over a source you care about.

The deterministic replacement:

1. Copy the DWG with the driving language.
2. Open the copy.
3. Select the keep-window with `ssget "_W"`.
4. Select everything with `ssget "_X"`, then `ssdel` the keep handles out of it.
5. `ERASE` the remainder.
6. `QSAVE` and `QUIT "_N"`.

Guard the whole thing so an empty keep-window never erases everything:

```lisp
(if w
  (progn ... (command "_.QSAVE") (write-line (itoa (sslength w)) f))
  (write-line "0" f))
```

## Sanity checks worth paying for

- Sum of per-output entity counts equals the source count, or differs only by the objects you deliberately excluded.
- Each output reopens with a non-zero entity count.
- Each output's own drawing number is present; no sibling's number appears.
- Source SHA-256 is identical before and after.
