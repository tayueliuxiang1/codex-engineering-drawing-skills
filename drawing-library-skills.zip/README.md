# Drawing Library Skills

Five agent skills for turning engineering drawing sets into a maintained profile library: split multi-sheet DWG/PDF, check the batch against an existing catalogue, add what is missing, and keep the workbook and the file folder in one-to-one correspondence.

Distilled from a real production job — 38 drawings across four sources, 630 catalogue rows, zero mismatches — rather than written from a spec. Every rule in here exists because its absence caused a specific, reproducible failure; the mistakes are catalogued in [docs/improvements.md](docs/improvements.md) and [skills/drawing-library-pipeline/references/case-2026-11.md](skills/drawing-library-pipeline/references/case-2026-11.md).

## Skills

| Skill | Role |
| --- | --- |
| [`drawing-library-pipeline`](skills/drawing-library-pipeline/SKILL.md) | The orchestrator: five stages, the artifact each stage hands over, and the gate that must pass before the next one starts. **Start here for a full batch-to-library job.** |
| [`drawing-split`](skills/drawing-split/SKILL.md) | Split a multi-sheet DWG or PDF into one file per sheet, named from the printed drawing number. Handles frameless sets, duplicate numbers, and sheets marked void. |
| [`library-audit`](skills/library-audit/SKILL.md) | Audit a batch against a catalogue workbook and its drawing folder; repair gaps by appending records and copying files; prove the one-to-one invariant. |
| [`excel-file-match`](skills/excel-file-match/SKILL.md) | Reconcile identifiers with a file library in a workbook: mark matches, add records with section pictures, keep formatting. |
| [`autocad-automation`](skills/autocad-automation/SKILL.md) | The mechanics under all of the above: headless AutoCAD, AutoLISP, DXF export, and the console's failure modes. |

## The workflow

```
drawings  ──split──▶  single files + 拆分清单.csv
                          │
                          ├──audit──▶ 对照报告  ──repair──▶  catalogue row + library file
                          │
                          └──register──▶  workbook with section pictures
                                             │
                                             ▼
                                      invariant: every row has a file
```

Order matters. Auditing before splitting wastes the run; writing a row before copying the file leaves a record pointing at nothing.

## Install

The skills follow the `SKILL.md` + YAML frontmatter convention (name, description, optional references and scripts), so they work with any agent that loads skills from a directory.

For DeepSeek Harness, copy the folders to the user-level skill root so they apply to every workspace:

```powershell
Copy-Item skills\* "$env:USERPROFILE\.dsh\skills\" -Recurse
```

Project-scoped instead (`<project>\.dsh\skills\` or `<project>\.agents\skills\`) works too. Restart or wait for the catalog to refresh; the harness watches the directory.

Other harnesses: point your skill loader at `skills/` and keep the folder names.

## Requirements

| Capability | Needed for | Notes |
| --- | --- | --- |
| AutoCAD + `accoreconsole.exe` | every DWG stage | tested on AutoCAD 2027 (ACADVER 26.0) |
| Excel (COM) | reading/writing a legacy `.xls` catalogue | `openpyxl` cannot open `.xls` |
| Python 3 with PyMuPDF (`fitz`), openpyxl, Pillow | PDF split, workbook edits, previews | `drawing-split/scripts/probe_env.py` reports what is present |
| Windows | all of the above | the console and COM paths are Windows-only |

Run the probe first; a missing capability stops one stage, not the pipeline.

## Quick start

Ask the agent to file a batch, or drive the stages yourself:

1. **Split** — "split `drawings.dwg` into one file per sheet". Expect a flat folder plus `拆分清单.csv`.
2. **Audit** — "check these against the library at `…\型材图库` with `catalogue.xls`". Expect a per-drawing verdict table.
3. **Repair** — only if the audit found gaps. The catalogue is backed up, the file is copied, the row is appended, then the invariant is re-checked.
4. **Register** — build or refresh the workbook, with one section picture per row, locked inside its cell.

## Design notes

- **Judgement and mechanics are separate skills.** A mechanical bug (dimensions vanishing because `DIMENSION` blocks were not expanded) and a judgement call (two sheets sharing one drawing number) fail differently and are fixed in different places.
- **Artifacts are contracts.** Four column names are frozen because later stages look them up by name; renaming `图号` to something prettier caused a `KeyError` downstream.
- **Verification is executable.** Every stage states an assertion — entity totals reconcile, no sibling identifier leaks, every catalogue row resolves to a file — instead of "inspect the output".
- **Blanks are findings.** A field the drawing does not state stays empty and gets flagged; the pipeline never invents a material, a dimension, or an identifier.

## Repository layout

```
skills/                     the five skills, one directory each
  <skill>/SKILL.md          entry point
  <skill>/references/       detail loaded on demand
  <skill>/scripts/          runnable helpers
docs/improvements.md        what changed across two rounds of real use, and why
```

## Licence

MIT — see [LICENSE](LICENSE).
